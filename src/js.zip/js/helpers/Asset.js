import config from "../core/config";

/**
 * @module Asset
 * @description
 * Helper para la gestión profesional de recursos estáticos (logos, avatares, fondos).
 */

const Asset = {
	/**
	 * Obtiene la ruta base de las imágenes
	 * @returns {string}
	 */
	getBasePath: () => config.assets?.basePath || "/img",

	/**
	 * Obtiene el URL de un logo específico
	 * @param {string} variant Variante del logo (compact, horizontal, sidebar, login, etc.)
	 * @returns {string}
	 */
	logo: (variant = "default") => {
		const logos = config.assets?.logos || {};
		const fileName = logos[variant] || logos.default || "logo.svg";
		return `${Asset.getBasePath()}${logos.path || "/logos"}/${fileName}`;
	},

	/**
	 * Obtiene el URL de un avatar
	 * @param {string} fileName Nombre del archivo de avatar
	 * @returns {string}
	 */
	avatar: (fileName) => {
		const avatars = config.assets?.avatars || {};
		const file = fileName || avatars.default || "avatar.jpg";
		return `${Asset.getBasePath()}${avatars.path || "/avatars"}/${file}`;
	},

	/**
	 * Obtiene el URL de una imagen de fondo
	 * @param {string} fileName
	 * @returns {string}
	 */
	bg: (fileName) => {
		const bgs = config.assets?.backgrounds || {};
		return `${Asset.getBasePath()}${bgs.path || "/bg"}/${fileName}`;
	},

	/**
	 * Obtiene la ruta de un empleado
	 * @param {string|number} id ID o nombre del archivo
	 * @returns {string}
	 */
	user: (id) => {
		const fileName = typeof id === "number" ? `${id}.png` : id;
		return `${Asset.getBasePath()}/employees/${fileName || "default.png"}`;
	},

	/**
	 * Obtiene una imagen genérica del sistema
	 * @param {string} subPath Subdirectorio dentro de /img
	 * @param {string} fileName
	 * @returns {string}
	 */
	img: (subPath, fileName) => {
		return `${Asset.getBasePath()}/${subPath}/${fileName}`;
	},

	/**
	 * Obtiene un placeholder en caso de error o ausencia
	 * @param {"user"|"image"} type
	 * @returns {string}
	 */
	placeholder: (type = "image") => {
		const placeholders = config.assets?.placeholders || {};
		return `${Asset.getBasePath()}${placeholders[type] || "/photos/unsplash-1.jpg"}`;
	}
};

export default Asset;
